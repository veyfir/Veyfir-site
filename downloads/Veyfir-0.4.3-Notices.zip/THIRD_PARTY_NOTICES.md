# Third-party acknowledgements

Veyfir's Windows development, product direction and maintenance are by Astro; publisher display is prod. GB. Existing third-party grants and copyright notices remain applicable.

| Component | Retained terms and notices |
| --- | --- |
| Original project material | [Original MIT notice](LICENSES/Vestige-MIT.txt), retained verbatim; historical project provenance is not a claim that its author developed the Windows implementation |
| OBS Studio/libobs 32.0.1 | [GPL text](LICENSES/OBS-GPL.txt), upstream source headers and the component-specific notices under [OBS-dependencies](LICENSES/OBS-dependencies) |
| FFmpeg7.1.1 OBS dependency utility and libraries | [GPLv3 text](LICENSES/FFmpeg-GPL.txt), upstream headers/build notices; exact OBS recipe/source pins retained; full native closure remains incomplete |
| NAudio 1.10 | [Microsoft Public License](LICENSES/NAudio-Ms-PL.txt); do not substitute later NAudio licence terms |
| NetSparkle core 3.1.0 and pinned dependencies | [Exact retained notices](LICENSES/Updater-NOTICES.txt); package/repository revision pins accompany the Windows source |
| Microsoft runtimes | Separately licensed Microsoft redistributables; the official runtime installer presents its terms when installation is required |

The upstream OBS dependency notices include transitive/optional components from its distribution; their presence does not mean every optional OBS feature is included in Veyfir. Qt and Chromium/CEF are not shipped in the current Windows payload.

Veyfir's app exposes complete licence texts through Settings â†’ About â†’ Third-party acknowledgements, in collapsed sections. No original copyright notice is replaced by the current branding. [SOURCE.md](SOURCE.md) records matching source material and unresolved items. This prepared document is not distribution approval or a new blanket licence.
