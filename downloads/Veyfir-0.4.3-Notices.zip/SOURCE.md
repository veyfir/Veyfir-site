# Windows source and build material

Local review only: native source closure remains incomplete; no production signing or publication.

## Exact application and native inputs

The Windows source archive contains368 committed build inputs from application commit `c884666e6a99cbc2d975a9430c2bb367636065e4`. The package index SHA256 is `1BB3E40EEFF942DD0877BBBFA8DF0B1D938200B3C91BDB83537BB66AB02892F3`. It contains frontend, GPL worker, protocol, resources and build scripts; no .git history, private keys, personal media/settings or generated output.

All59 existing runtime/resource pins match the official OBS32.0.1 Windows archive. The optional FFmpeg7.1.1 utility is from the official OBS-deps2025-08-23 archive and runs beside those same DLLs. Its exact hash, core revision, archive and recipe are in SOURCE-PINS.json and Windows/MediaToolManifest.json. Twelve dependency DLL images match the dependency archive after excluding only PE checksum/security-directory/signature bytes; raw signed and unsigned hashes differ. No Gyan standalone executable is in this package.

The native-source asset contains matching retained OBS, FFmpeg, dependency and NAudio source inputs, plus the complete retained OBS-deps recipe/patch archive. AMD headers match the recipe's sparse public-include subtree and each source blob was checked against its pinned Git object. LAME3.100 source from Debian matches the exact OBS recipe SHA256. This asset is explicitly PARTIAL: SOURCE-STATUS.json identifies the remaining inputs/review. It must not be advertised as complete corresponding source.

NAudio1.10 is Ms-PL; its official NuGet binary and exact tag source match. Updater source/package pins and notices are under Windows/vendor/updates. Applicable texts are retained byte for byte under LICENSES. These facts do not assign a new blanket licence to all Windows components or conclude that IPC exempts the frontend from obligations.

## Rebuilding the managed application and package

Extract the Windows source archive to a new folder. Initialize and commit a local Git repository before building; build scripts require Git and should describe that actual local revision. Do not change global Git identity or pretend the new local commit is the original release revision.

Use the existing Microsoft .NET Framework4.8 compiler/WPF assemblies, PowerShell and Git. Windows/build.ps1 builds the managed application. Build-only tools are not included. Do not bypass PowerShell or system security policy.

For the full recording package, obtain the exact OBS32.0.1 x64 archive in SOURCE-PINS.json, verify its published SHA256, and extract it to a dedicated folder. Obtain and verify the exact windows-deps archive from MediaToolManifest.json; its bin/ffmpeg.exe must match the manifest's byte count/hash. Copy only that executable to a dedicated cache path. Run Windows/Build-Alpha03.ps1 with a new Windows/dist output, -ObsSource pointing to extracted OBS, -UseObsMediaTool and -ObsMediaToolSource pointing to the verified utility. It stages the existing pinned runtime; it does not install OBS or alter global PATH. Without -UseObsMediaTool the historical standalone packaging path remains available separately.

Windows/packaging/Build-Installer.ps1 additionally requires the separately reviewed Inno compiler and official Microsoft prerequisites pinned by Windows/packaging/Prerequisites.json. Native rebuilding must use exact retained recipes, patches, source revisions and required submodules; the unresolved native closure prevents a complete rebuild claim today.

## Platforms and approval

This inventory covers Windows only. Obtain the Mac maintainer's current matching binary/source separately. Production signing, repository writes and publication require explicit owner approval of the exact completed candidate. Retained material is not permission to publish it automatically.

## 2026-10-29 source-input follow-up

Eight declared submodule source archives are now retained at their exact parent Git-link commits, with no further declared nested submodules. They include optional/test inputs; inclusion does not mean every component is shipped. All18 patches identified in the retained recipe scripts match their stated SHA256 values. No upstream build script or patch was executed.

Official Vulkan-Headers sdk-1.3.216.0 source is retained at commit3ef4c97fd6ea001d75a8e9da408ee473c180e456. The C headers directly included by OBS's Vulkan capture source match the pinned dependency package after line-ending normalization. Additional SDK-generated/profile/C++ headers are not all covered by that comparison; no all-SDK or driver compatibility claim is made. This is source data, not an SDK/driver installation.

Official libpng1.6.47 source is retained at commit872555f4ba910252783af1507f9e7fe1653be252. This is an alternate source archive, not the unavailable SourceForge zip and not a false claim that the original archive checksum passed. The retained Windows Theora CMake patch links only Ogg and builds no PNG examples; Veyfir omits Qt/frontend/text plugins. The required native build closure still needs a final scoped review. The sources remain labelled PARTIAL rather than inventing a native rebuild or resolving legal questions from hashes alone.

The Windows application source/installer is unchanged from c884666; later source-collection and audit work does not require a new recorder build. Production signing/publication and all clean-machine/hosted acceptance remain separately gated.
